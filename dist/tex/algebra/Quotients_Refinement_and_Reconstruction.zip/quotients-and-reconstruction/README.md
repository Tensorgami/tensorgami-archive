# Quotients, Refinement, and Reconstruction

This archive contains the complete native TeX inputs for the 82-page PDF and
matching full web exposition. Compile main.tex with pdfLaTeX until references
and the table of contents stabilize (normally three runs on a clean build).
The preamble lists the required standard packages, including TikZ-CD.

Clarification edition: October 22, 2026. Three explanatory passages name the
scaled shear, distinguish representative choice from the canonical inclusion,
and state the ambient assumptions for higher quotient and descent results.
The appendix links the public audit report. The theorem numbering and diagrams
are unchanged.

Read: https://tensorgami.com/notes/quotients-and-reconstruction.html
PDF: https://tensorgami.com/pdfs/algebra/Quotients_Refinement_and_Reconstruction.pdf
Audit: https://tensorgami.com/notes/quotients-and-reconstruction-audit.html

The audit distinguishes the full preceding-edition proof review from the narrow
clarification review. It is not proof-assistant formalization.
